import { Routes } from '@angular/router';
import { ActivityComponent } from './components/activity/activity.component';
import { WorkoutComponent} from './components/workout/workout.component'
import { GoalComponent } from './components/goal/goal.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';


export const routes: Routes = [
    { path: '', redirectTo: 'activity', pathMatch: 'full' }, // Redirect root to activity
    { path: 'activity', component: ActivityComponent },
    { path: 'workout', component: WorkoutComponent },
    { path: 'goal', component: GoalComponent }, 
    {path:'dashboard', component: DashboardComponent},
    { path: '**', redirectTo: 'activity' } // Catch-all route should be last
];

