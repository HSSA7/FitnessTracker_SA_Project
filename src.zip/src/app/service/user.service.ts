import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { tap } from 'rxjs/operators';

const BASIC_URL = "http://localhost:8080/";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) {}

  // ✅ Post a new activity
  postActivity(activityDTO: any): Observable<any> {
    const formattedDTO = { 
      ...activityDTO, 
      date: new Date(activityDTO.date).toISOString()
    };

    console.log('🚀 Sending activity:', formattedDTO);

    return this.http.post(BASIC_URL + "api/activity", formattedDTO).pipe(
      catchError(error => this.handleError("posting activity", error))
    );
  }

  // ✅ Fetch all activities
  getActivities(): Observable<any> {
    console.log('📡 Fetching activities...');

    return this.http.get<any>(BASIC_URL + "api/activities").pipe(
      tap(data => console.log('✅ Activities received:', data)),
      catchError(error => this.handleError("fetching activities", error))
    );
  }

  // ✅ Post a new workout
  postWorkout(workoutDTO: any): Observable<any> {
    const formattedDTO = { 
      ...workoutDTO, 
      date: new Date(workoutDTO.date).toISOString()
    };

    console.log('💪 Sending workout:', formattedDTO);

    return this.http.post(BASIC_URL + "api/workout", formattedDTO).pipe(
      catchError(error => this.handleError("posting workout", error))
    );
  }

  // ✅ Fetch all workouts
  getWorkouts(): Observable<any> {
    console.log('📡 Fetching workouts...');

    return this.http.get<any>(BASIC_URL + "api/workouts").pipe(
      tap(data => console.log('✅ Workouts received:', data)),
      catchError(error => this.handleError("fetching workouts", error))
    );
  }

  // ✅ Post a new goal
  postGoal(goalDTO: any): Observable<any> {
    const formattedDTO = { 
      ...goalDTO, 
      startDate: new Date(goalDTO.startDate).toISOString(),
      endDate: new Date(goalDTO.endDate).toISOString()
    };

    console.log('🎯 Sending goal:', formattedDTO);

    return this.http.post(BASIC_URL + "api/goal", formattedDTO).pipe(
      catchError(error => this.handleError("posting goal", error))
    );
  }

  // ✅ Fetch all goals
  getGoals(): Observable<any> {
    console.log('📡 Fetching goals...');

    return this.http.get<any>(BASIC_URL + "api/goals").pipe(
      tap(data => console.log('✅ Goals received:', data)),
      catchError(error => this.handleError("fetching goals", error))
    );
  }

  // ✅ Update goal status (Changed from `GET` to `PUT`)
  updateGoalStatus(id: number): Observable<any> {
    console.log(`📡 Updating status for goal ID: ${id}...`);

    return this.http.get<any>(`${BASIC_URL}api/goal/status/${id}`, {}).pipe(
      tap(data => console.log(`✅ Goal status updated for ID ${id}:`, data)),
      catchError(error => this.handleError(`updating goal status for ID ${id}`, error))
    );
  }

  // ✅ Handle errors in a reusable way
  private handleError(operation: string, error: any) {
    console.error(`❌ Error ${operation}:`, error);
    alert(`Error ${operation}: ${error.status} - ${error.message}`);
    return throwError(() => new Error(error.message));
  }

  // ✅ Get stats
  getStats(): Observable<any> {
    console.log('📊 Fetching stats...');

    return this.http.get<any>(BASIC_URL + "api/stats").pipe(
      tap(data => console.log('✅ Stats received:', data)),
      catchError(error => this.handleError("fetching stats", error))
    );
  }

  getGraphStats(): Observable<any> {
    console.log('📊 Fetching graph stats...');

    return this.http.get<any>(BASIC_URL + "api/graphs").pipe(
      tap(data => console.log('✅ Graph stats received:', data)),
      catchError(error => this.handleError("fetching graph stats", error))
    );
  }

  
}


