import { Component, ElementRef, OnInit, ViewChild, AfterViewInit, PLATFORM_ID, Inject } from '@angular/core';
import { UserService } from '../../service/user.service';
import { SharedModule } from '../../shared/shared.module';
import Chart, { CategoryScale } from 'chart.js/auto';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { DatePipe, isPlatformBrowser } from '@angular/common';

Chart.register(CategoryScale);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [SharedModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  providers: [DatePipe]
})
export class DashboardComponent implements OnInit, AfterViewInit {
  statsData: any = {
    totalCaloriesBurned: 0,
    distance: 0,
    steps: 0,
    duration: 0,
    achievedGoals: 0,
    notAchievedGoals: 0
  };
  
  workouts: any = [];
  activities: any = [];
  workoutChart: Chart | null = null;
  activityChart: Chart | null = null;

  @ViewChild('workoutLineChart') private workoutLineChartRef!: ElementRef;
  @ViewChild('activityLineChart') private activityLineChartRef!: ElementRef;

  constructor(
    private userService: UserService,
    private datePipe: DatePipe,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    this.getStats();
    this.getGraphStats();
  }

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => {
        if (this.workouts.length > 0) {
          this.createWorkoutChart();
        }
        if (this.activities.length > 0) {
          this.createActivityChart();
        }
      }, 0);
    }
  }

  getStats(): void {
    this.userService.getStats().pipe(
      catchError(err => {
        console.error('Error fetching stats:', err);
        return of(this.statsData);
      })
    ).subscribe(
      (res) => {
        console.log('Stats data:', res);
        this.statsData = res;
      }
    );
  }

  getGraphStats(): void {
    this.userService.getGraphStats().pipe(
      catchError(err => {
        console.error('Error fetching graph stats:', err);
        return of({ workouts: [], activities: [] });
      })
    ).subscribe(
      (res) => {
        this.workouts = res.workouts || [];
        this.activities = res.activities || [];
        console.log('Graph data - Workouts:', this.workouts);
        console.log('Graph data - Activities:', this.activities);

        if (isPlatformBrowser(this.platformId)) {
          setTimeout(() => {
            if (this.workoutLineChartRef && this.workouts.length > 0) {
              this.createWorkoutChart();
            }
            if (this.activityLineChartRef && this.activities.length > 0) {
              this.createActivityChart();
            }
          }, 0);
        }
      }
    );
  }

  createWorkoutChart(): void {
    if (!isPlatformBrowser(this.platformId) || !this.workoutLineChartRef) {
      return;
    }

    const workoutCtx = this.workoutLineChartRef.nativeElement.getContext('2d');
    
    if (!workoutCtx) {
      console.warn('Could not get workout chart context');
      return;
    }

    // Destroy existing chart if it exists
    if (this.workoutChart) {
      this.workoutChart.destroy();
    }
    
    this.workoutChart = new Chart(workoutCtx, {
      type: 'line',
      data: {
        labels: this.workouts.map((data: any) => this.datePipe.transform(data.date, 'MMM d')),
        datasets: [{
          label: 'Calories Burnt',
          data: this.workouts.map((data: any) => data.caloriesBurnt),
          borderWidth: 2,
          fill: false,
          tension: 0.4,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)'
        },
        {
          label: 'Duration',
          data: this.workouts.map((data: any) => data.duration),
          borderWidth: 2,
          fill: false,
          tension: 0.4,
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgba(255, 99, 132, 1)'
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
    console.log('Workout chart initialized');
  }

  createActivityChart(): void {
    if (!isPlatformBrowser(this.platformId) || !this.activityLineChartRef) {
      return;
    }

    const activityCtx = this.activityLineChartRef.nativeElement.getContext('2d');
    
    if (!activityCtx) {
      console.warn('Could not get activity chart context');
      return;
    }

    // Destroy existing chart if it exists
    if (this.activityChart) {
      this.activityChart.destroy();
    }
    
    console.log('Creating activity chart with data:', this.activities);
    
    this.activityChart = new Chart(activityCtx, {
      type: 'line',
      data: {
        labels: this.activities.map((data: {date:any;}) => this.datePipe.transform(data.date, 'MM/dd')),
        datasets: [
          {
            label: 'Calories Burnt',
            data: this.activities.map((data: any) => data.caloriesBurnt),
            borderWidth: 2,
            fill: false,
            tension: 0.4,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)'
          },
          {
            label: 'Steps',
            data: this.activities.map((data: any) => data.steps),
            borderWidth: 2,
            fill: false,
            tension: 0.4,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)'
          },
          {
            label: 'Distance',
            data: this.activities.map((data: any) => data.distance),
            borderWidth: 2,
            fill: false,
            tension: 0.4,
            backgroundColor: 'rgba(255, 206, 86, 0.2)',
            borderColor: 'rgba(255, 206, 86, 1)'
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
    console.log('Activity chart initialized');
  }
}
