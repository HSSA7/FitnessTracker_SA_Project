import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { UserService } from '../../service/user.service';
import { format } from 'date-fns';

@Component({
  selector: 'app-activity',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzCardModule,
    NzFormModule,
    NzInputModule,
    NzButtonModule,
    NzDatePickerModule
  ],
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.scss']
})
export class ActivityComponent {
  
  activityForm!: FormGroup;
  activities:any;
  isSubmitting = false; // Prevent multiple submissions

  gridstyle = { 
    width: '100%', 
    textAlign: 'center' 
  };

  constructor(
    private fb: FormBuilder, 
    private message: NzMessageService,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.activityForm = this.fb.group({
      caloriesBurnt: [null, [Validators.required, Validators.min(1)]], 
      steps: [null, [Validators.required, Validators.min(1)]], 
      distance: [null, [Validators.required, Validators.min(0.1)]], 
      date: [null, [Validators.required]]
    });

    this.getAllActivities();
  }

  submitForm() {
    if (this.activityForm.invalid) {
      this.message.error("Please fill all required fields correctly", { nzDuration: 5000 });
      return;
    }

    this.isSubmitting = true;

    const formData = {
      caloriesBurnt: Number(this.activityForm.value.caloriesBurnt),
      steps: Number(this.activityForm.value.steps),
      distance: Number(this.activityForm.value.distance),
      date: format(new Date(this.activityForm.value.date), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'") // Standard format
    };

    this.userService.postActivity(formData).subscribe({
      next: () => {
        this.message.success("Activity posted successfully!", { nzDuration: 5000 });
        this.activityForm.reset();
        this.isSubmitting = false;
        this.getAllActivities();
      },
      error: (err) => {
        console.error("API Error:", err);
        this.message.error(`Error: ${err.error?.message || "Failed to post activity"}`, { nzDuration: 5000 });
        this.isSubmitting = false;
      }
    });
  }

  getAllActivities(){
    this.userService.getActivities().subscribe(res=>{
      this.activities = res;
      console.log(this.activities);
    }
   )
  }
}
