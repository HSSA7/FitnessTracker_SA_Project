import { Component } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzIconModule } from 'ng-zorro-antd/icon';

@Component({
  selector: 'app-goal',
  standalone: true,
  imports: [SharedModule, NzIconModule],
  templateUrl: './goal.component.html',
  styleUrls: ['./goal.component.scss']
})
export class GoalComponent {
  gridStyle = {
    width: '100%',
    textAlign: 'center'
  };

  goals: any[] = []; // ✅ Stores list of goals
  goalForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private message: NzMessageService
  ) {}

  ngOnInit() {
    this.goalForm = this.fb.group({
      description: [null, [Validators.required, Validators.minLength(1)]],
      startDate: [null, [Validators.required]],
      endDate: [null, [Validators.required]]
    });
    this.getAllGoals(); // ✅ Fetch existing goals on component load
  }

  // ✅ Fetch Goals from Backend
  getAllGoals() {
    this.userService.getGoals().subscribe({
      next: (res: any[]) => {
        this.goals = res;
        console.log("📡 Goals retrieved:", this.goals);
      },
      error: err => {
        console.error("❌ Error fetching goals:", err);
        this.message.error("Failed to fetch goals.");
      }
    });
  }

  // ✅ Submit New Goal
  submitForm() {
    if (this.goalForm.valid) {
      const goalData = this.goalForm.value;
      console.log("🎯 Submitting goal:", goalData);

      this.userService.postGoal(goalData).subscribe({
        next: () => {
          this.message.success("Goal posted successfully!", { nzDuration: 5000 });
          this.getAllGoals(); // Refresh goals list after submission
          this.resetForm(); // Clear form
        },
        error: err => {
          console.error("❌ Error submitting goal:", err);
          this.message.error("Failed to submit goal. Please try again.");
        }
      });
    } else {
      this.message.error("Please fill in all required fields.");
    }
  }

  // ✅ Reset Form After Successful Submission
  resetForm() {
    this.goalForm.reset();
    Object.keys(this.goalForm.controls).forEach(key => {
      this.goalForm.controls[key].setErrors(null);
    });
  }

  // ✅ Update Goal Status
  updateStatus(id: number) {
    this.userService.updateGoalStatus(id).subscribe({
      next: () => {
        this.message.success("✅ Goal updated successfully", { nzDuration: 5000 });
        this.getAllGoals(); // Refresh goals after updating
      },
      error: err => {
        this.message.error("❌ Error while updating goal", { nzDuration: 5000 });
        console.error("Error:", err);
      }
    });
  }
}