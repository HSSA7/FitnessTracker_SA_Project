package com.SA_project.FitBitsSolanki.repository;

import com.SA_project.FitBitsSolanki.entity.Goal;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

@Repository
public interface GoalRepository extends JpaRepository<Goal, Long>
{


    @Query("SELECT COUNT(g) FROM Goal g WHERE g.achieved = true")
     Long countAchievedGoals();
    @Query("SELECT COUNT(g) FROM Goal g WHERE g.achieved = false")
    Long countNotAchievedGoals();


}
