package com.SA_project.FitBitsSolanki.entity;

import com.SA_project.FitBitsSolanki.dto.WorkoutDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.util.Date;

@Entity
@Data
public class Workout {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;

    // Stores both date and time
    private Date date;

    private int duration; // Duration in minutes

    private double caloriesBurnt; // Calories burned during the workout

    // Convert Entity to DTO
    public WorkoutDTO getWorkoutDTO() {
        return new WorkoutDTO(this.id, this.type, this.date, this.duration, this.caloriesBurnt);
    }
}
