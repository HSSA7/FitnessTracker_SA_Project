package com.SA_project.FitBitsSolanki.entity;

import com.SA_project.FitBitsSolanki.dto.GoalDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data // ✅ Generates Getters, Setters, toString, equals, hashCode
public class Goal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;
    private LocalDateTime startDate; // ✅ Ensure camel case
    private LocalDateTime endDate;   // ✅ Ensure camel case
    private boolean achieved;

    // ✅ Converts Goal entity to GoalDTO
    public GoalDTO getGoalDTO() {
        GoalDTO goalDTO = new GoalDTO();

        goalDTO.setId(id);
        goalDTO.setDescription(description);
        goalDTO.setStartDate(startDate); // ✅ Match naming convention
        goalDTO.setEndDate(endDate);     // ✅ Match naming convention
        goalDTO.setAchieved(achieved);

        return goalDTO;
    }


}
