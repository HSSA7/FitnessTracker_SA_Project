package com.SA_project.FitBitsSolanki.entity;

import com.SA_project.FitBitsSolanki.dto.ActivityDTO;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Data
@NoArgsConstructor  // ✅ Added no-args constructor (required by JPA)
@AllArgsConstructor // ✅ Added parameterized constructor
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Date date;
    private int steps;
    private double distance;
    private int caloriesBurnt;

    public ActivityDTO getActivityDTO() {
        return new ActivityDTO(id, date, steps, distance, caloriesBurnt);
    }
}
