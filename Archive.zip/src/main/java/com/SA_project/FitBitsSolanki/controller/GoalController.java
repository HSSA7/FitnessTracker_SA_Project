package com.SA_project.FitBitsSolanki.controller;

import com.SA_project.FitBitsSolanki.dto.GoalDTO;
import com.SA_project.FitBitsSolanki.services.goal.GoalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
// Allow all origins


public class GoalController {

    private final GoalService goalService;

    @PostMapping("/goal")
    public ResponseEntity<?> postGoal(@RequestBody GoalDTO dto) {
        try {
            // Debugging logs
            System.out.println("Received Goal Data: " + dto);
            System.out.println("Start Date: " + dto.getStartDate());
            System.out.println("End Date: " + dto.getEndDate());

            if (dto.getStartDate() == null || dto.getEndDate() == null) {
                return ResponseEntity.badRequest().body("StartDate and EndDate are required!");
            }

            return ResponseEntity.status(HttpStatus.CREATED).body(goalService.postGoal(dto));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/goals")
    public ResponseEntity<?> getGoals(){
        try {
            return ResponseEntity.ok(goalService.getGoals());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong.");
        }
    }

    @GetMapping("/goal/status/{id}")
    public ResponseEntity<?> updateStatus(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(goalService.updateStatus(id));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }


}
