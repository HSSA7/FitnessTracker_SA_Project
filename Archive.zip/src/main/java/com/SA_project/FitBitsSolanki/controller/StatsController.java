package com.SA_project.FitBitsSolanki.controller;

import com.SA_project.FitBitsSolanki.dto.GraphDTO;
import com.SA_project.FitBitsSolanki.services.stats.StatsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin("*")
public class StatsController {

    private final StatsService statsService;

    @GetMapping("/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(statsService.getStats());
    }

    @GetMapping("/graphs")
    public ResponseEntity<?> getGraphStats() {
        GraphDTO graphDTO = statsService.getGraphStats(); // Call service method

        if (graphDTO != null) {
            return ResponseEntity.ok(graphDTO); // Return 200 OK with data
        } else {
            return ResponseEntity.status(404).body(null); // Return 404 if no data found
        }
    }

}
