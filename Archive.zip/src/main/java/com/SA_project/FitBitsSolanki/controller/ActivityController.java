package com.SA_project.FitBitsSolanki.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import lombok.RequiredArgsConstructor;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import akka.actor.ActorSelection;
import akka.actor.ActorSystem;
import akka.pattern.Patterns;
import akka.util.Timeout;               // <-- KEY import for the classic approach
import scala.concurrent.Future;
import scala.concurrent.duration.Duration;
import scala.compat.java8.FutureConverters;

import com.SA_project.FitBitsSolanki.actors.ActivityActor;
import com.SA_project.FitBitsSolanki.dto.ActivityDTO;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ActivityController {

    private final ActorSystem actorSystem;
    private static final Logger logger = LoggerFactory.getLogger(ActivityController.class);

    @PostMapping("/activity")
    public CompletableFuture<ResponseEntity<?>> postActivity(@RequestBody ActivityDTO dto) {
        // Basic validation
        if (dto.getDate() == null || dto.getSteps() <= 0 || dto.getDistance() <= 0) {
            return CompletableFuture.completedFuture(
                    ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid activity data.")
            );
        }

        logger.info("📨 Received ActivityDTO: {}", dto);

        // 1) Use akka.util.Timeout for the classic ask
        Timeout timeout = new Timeout(Duration.create(5, TimeUnit.SECONDS));

        // 2) Patterns.ask(...) => Scala Future<Object>
        ActorSelection actor = actorSystem.actorSelection("/user/activity-actor");
        Future<Object> scalaFuture = Patterns.ask(
                actor,
                new ActivityActor.PostActivity(dto),
                timeout
        );

        // 3) Convert Scala Future -> Java CompletableFuture<Object>
        return FutureConverters
                .toJava(scalaFuture)
                .toCompletableFuture()
                .thenApply(response -> {
                    logger.info("✅ Actor response: {}", response);
                    return ResponseEntity.status(HttpStatus.CREATED).body(response);
                });
    }

    @GetMapping("/activities")
    public CompletableFuture<ResponseEntity<?>> getActivities() {
        logger.info("📨 Request to fetch all activities via Actor.");

        // 1) Use akka.util.Timeout for the classic ask
        Timeout timeout = new Timeout(Duration.create(5, TimeUnit.SECONDS));

        // 2) Patterns.ask(...) => Scala Future<Object>
        ActorSelection actor = actorSystem.actorSelection("/user/activity-actor");
        Future<Object> scalaFuture = Patterns.ask(
                actor,
                new ActivityActor.GetActivities(),
                timeout
        );

        // 3) Convert Scala Future -> Java CompletableFuture<Object>
        return FutureConverters
                .toJava(scalaFuture)
                .toCompletableFuture()
                .thenApply(response -> {
                    logger.info("📚 Fetched activities: {}", response);
                    return ResponseEntity.ok(response);
                });
    }
}
