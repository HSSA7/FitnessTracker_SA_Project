package com.SA_project.FitBitsSolanki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitBitsSolankiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitBitsSolankiApplication.class, args);
	}

}
