package com.SA_project.FitBitsSolanki.services.activity;

import com.SA_project.FitBitsSolanki.dto.ActivityDTO;

import java.util.List;

public interface ActivityServices {

    ActivityDTO postActivity(ActivityDTO dto);

    List<ActivityDTO> getActivites();
}
