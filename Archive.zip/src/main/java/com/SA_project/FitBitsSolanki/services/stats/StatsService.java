package com.SA_project.FitBitsSolanki.services.stats;

import com.SA_project.FitBitsSolanki.dto.GraphDTO;
import com.SA_project.FitBitsSolanki.dto.StatsDTO;

public interface StatsService {

    StatsDTO getStats();
    GraphDTO getGraphStats();
}
