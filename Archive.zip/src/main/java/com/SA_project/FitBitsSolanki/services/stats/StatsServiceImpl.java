package com.SA_project.FitBitsSolanki.services.stats;

import com.SA_project.FitBitsSolanki.dto.GraphDTO;
import com.SA_project.FitBitsSolanki.dto.StatsDTO;
import com.SA_project.FitBitsSolanki.dto.WorkoutDTO;
import com.SA_project.FitBitsSolanki.entity.Activity;
import com.SA_project.FitBitsSolanki.entity.Workout;
import com.SA_project.FitBitsSolanki.repository.ActivityRepository;
import com.SA_project.FitBitsSolanki.repository.GoalRepository;
import com.SA_project.FitBitsSolanki.repository.WorkoutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatsServiceImpl implements StatsService {

    private final GoalRepository goalRepository;
    private final ActivityRepository activityRepository;
    private final WorkoutRepository workoutRepository;

    public StatsDTO getStats() {
        Long achievedGoals = goalRepository.countAchievedGoals();
        Long notAchievedGoals = goalRepository.countNotAchievedGoals();
        Integer totalSteps = activityRepository.getTotalSteps();
        Double totalDistance = activityRepository.getTotalDistance();
        Integer totalActivityCaloriesBurnt = activityRepository.getTotalActivityCalories();
        Integer totalWorkoutDuration = workoutRepository.getTotalDuration();
        Integer totalWorkoutCaloriesBurnt = workoutRepository.getTotalCaloriesBurnt();

        int totalCaloriesBurnt = (totalActivityCaloriesBurnt != null ? totalActivityCaloriesBurnt : 0) +
                (totalWorkoutCaloriesBurnt != null ? totalWorkoutCaloriesBurnt : 0);

        StatsDTO dto = new StatsDTO();
        dto.setAchievedGoals(achievedGoals != null ? achievedGoals : 0);
        dto.setNotAchievedGoals(notAchievedGoals != null ? notAchievedGoals : 0);
        dto.setSteps(totalSteps != null ? totalSteps : 0);
        dto.setDistance(totalDistance != null ? totalDistance : 0.0);
        dto.setTotalCaloriesBurnt(totalCaloriesBurnt);
        dto.setDuration(totalWorkoutDuration != null ? totalWorkoutDuration : 0);

        return dto;
    }

    public GraphDTO getGraphStats() {
        Pageable pageable = PageRequest.of(0, 7);

        List<Workout> workouts = workoutRepository.findTop7ByOrderByDateDesc(pageable);
        List<Activity> activities = activityRepository.findTop7ByOrderByDateDesc(pageable);

        GraphDTO graphDTO = new GraphDTO();
        graphDTO.setWorkouts(
                workouts.stream()
                        .map(Workout::getWorkoutDTO)
                        .collect(Collectors.toList())
        );
        graphDTO.setActivities(
                activities.stream()
                        .map(Activity::getActivityDTO)
                        .collect(Collectors.toList())
        );

        return graphDTO;
    }
}
