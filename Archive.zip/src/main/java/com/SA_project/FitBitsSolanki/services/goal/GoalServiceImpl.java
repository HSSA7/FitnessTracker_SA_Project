package com.SA_project.FitBitsSolanki.services.goal;


import com.SA_project.FitBitsSolanki.dto.GoalDTO;
import com.SA_project.FitBitsSolanki.dto.WorkoutDTO;
import com.SA_project.FitBitsSolanki.entity.Goal;
import com.SA_project.FitBitsSolanki.entity.Workout;
import com.SA_project.FitBitsSolanki.repository.GoalRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GoalServiceImpl implements GoalService {

    private final GoalRepository goalRepository;

    public GoalDTO postGoal(GoalDTO dto) {
        System.out.println("Received GoalDTO: " + dto);
        Goal goal = new Goal();

        goal.setDescription(dto.getDescription());
        goal.setStartDate(dto.getStartDate()); // Fixed method name
        goal.setEndDate(dto.getEndDate());     // Fixed method name
        goal.setAchieved(false);


        return goalRepository.save(goal).getGoalDTO();
    }

    public List<GoalDTO> getGoals() {  // ✅ Fixed incorrect generic type
        List<Goal> goals = goalRepository.findAll();
        return goals.stream().map(Goal::getGoalDTO).collect(Collectors.toList());
    }


    public GoalDTO updateStatus(Long id) {
        Optional<Goal> optionalGoal = goalRepository.findById(id);

        if (optionalGoal.isPresent()) {
            Goal existingGoal = optionalGoal.get();
            existingGoal.setAchieved(true);

            // Save the updated goal back to the database
           return goalRepository.save(existingGoal).getGoalDTO();

            // Convert to DTO and return (assuming a conversion method exists)

        }

        throw new EntityNotFoundException("Goal Not Found.");
    }

}

