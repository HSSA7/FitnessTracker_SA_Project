package com.SA_project.FitBitsSolanki.services.activity;

import com.SA_project.FitBitsSolanki.dto.ActivityDTO;
import com.SA_project.FitBitsSolanki.entity.Activity;
import com.SA_project.FitBitsSolanki.repository.ActivityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ActivityServiceImpl implements ActivityServices {

    private static final Logger logger = LoggerFactory.getLogger(ActivityServiceImpl.class); // ✅ Corrected logger reference

    private final ActivityRepository activityRepository;

    public ActivityDTO postActivity(ActivityDTO dto) {
        try {
            logger.info("📩 Received ActivityDTO: {}", dto);

            // ✅ Creating an Activity object
            Activity activity = new Activity(null, dto.getDate(), dto.getSteps(), dto.getDistance(), dto.getCaloriesBurnt());

            logger.info("💾 Saving activity to database...");
            activity = activityRepository.save(activity); // ✅ Save in DB

            logger.info("✅ Activity saved successfully: {}", activity);

            // ✅ Returning DTO
            return new ActivityDTO(activity.getId(), activity.getDate(), activity.getSteps(), activity.getDistance(), activity.getCaloriesBurnt());

        } catch (Exception e) {
            logger.error("❌ Error saving activity: ", e);
            return null;
        }
    }

    public List<ActivityDTO> getActivites() {
        List<Activity> activities = activityRepository.findAll();
        return activities.stream().map(Activity::getActivityDTO).collect(Collectors.toList());
    }
}
