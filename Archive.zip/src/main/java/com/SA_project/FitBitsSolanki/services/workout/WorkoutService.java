package com.SA_project.FitBitsSolanki.services.workout;

import com.SA_project.FitBitsSolanki.dto.WorkoutDTO;
import java.util.List; // ✅ Import List from java.util

public interface WorkoutService {

    WorkoutDTO postWorkout(WorkoutDTO workoutDTO);

    List<WorkoutDTO> getWorkouts(); // ✅ Corrected List<WorkoutDTO>
}
