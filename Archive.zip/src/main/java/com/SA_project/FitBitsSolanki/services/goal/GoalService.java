package com.SA_project.FitBitsSolanki.services.goal;

import com.SA_project.FitBitsSolanki.dto.GoalDTO;

import java.util.List;

public interface GoalService {
    GoalDTO postGoal(GoalDTO dto);

    List<GoalDTO> getGoals();

    GoalDTO updateStatus(Long id);


}
