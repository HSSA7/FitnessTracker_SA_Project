package com.SA_project.FitBitsSolanki.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class GoalDTO {

    private Long id;
    private String description;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private boolean achieved;

    public void setStartDate(LocalDateTime startDate) { this.startDate = startDate; }
    public LocalDateTime getStartDate() { return startDate; }

    public void setEndDate(LocalDateTime endDate) { this.endDate = endDate; }
    public LocalDateTime getEndDate() { return endDate; }
}
