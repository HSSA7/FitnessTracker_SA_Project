package com.SA_project.FitBitsSolanki.dto;

import lombok.Data;
import java.util.Date;

@Data
public class WorkoutDTO {
    private Long id;
    private String type;
    private Date date;
    private int duration;
    private double caloriesBurnt;

    // No-argument constructor
    public WorkoutDTO() {
    }

    // Parameterized constructor
    public WorkoutDTO(Long id, String type, Date date, int duration, double caloriesBurnt) {
        this.id = id;
        this.type = type;
        this.date = date;
        this.duration = duration;
        this.caloriesBurnt = caloriesBurnt;
    }
}
