package com.SA_project.FitBitsSolanki.config;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import com.SA_project.FitBitsSolanki.actors.ActivityActor;
import com.SA_project.FitBitsSolanki.repository.ActivityRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ActorInitializer {

    @Bean
    public CommandLineRunner initActors(ActorSystem system, ActivityRepository repo) {
        return args -> {
            system.actorOf(ActivityActor.props(repo), "activity-actor");
        };
    }
}
