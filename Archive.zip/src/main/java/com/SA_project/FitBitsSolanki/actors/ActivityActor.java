package com.SA_project.FitBitsSolanki.actors;

import akka.actor.AbstractActor;
import akka.actor.Props;
import com.SA_project.FitBitsSolanki.dto.ActivityDTO;
import com.SA_project.FitBitsSolanki.entity.Activity;
import com.SA_project.FitBitsSolanki.repository.ActivityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;


@Component
@Scope("prototype") // Needed to inject Spring beans
@RequiredArgsConstructor

public class ActivityActor extends AbstractActor {

    private final ActivityRepository activityRepository;

    public static Props props(ActivityRepository repo) {
        return Props.create(ActivityActor.class, () -> new ActivityActor(repo));
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(PostActivity.class, this::handlePostActivity)
                .match(GetActivities.class, this::handleGetActivities)
                .build();
    }

    private void handlePostActivity(PostActivity msg) {
        ActivityDTO dto = msg.dto;
        Activity saved = activityRepository.save(
                new Activity(null, dto.getDate(), dto.getSteps(), dto.getDistance(), dto.getCaloriesBurnt())
        );
        getSender().tell(saved.getActivityDTO(), getSelf());
    }

    private void handleGetActivities(GetActivities msg) {
        List<ActivityDTO> dtos = activityRepository.findAll().stream()
                .map(Activity::getActivityDTO)
                .collect(Collectors.toList());
        getSender().tell(dtos, getSelf());
    }

    // --- Message Classes ---
    public static class PostActivity {
        public final ActivityDTO dto;
        public PostActivity(ActivityDTO dto) { this.dto = dto; }
    }

    public static class GetActivities {}
}
