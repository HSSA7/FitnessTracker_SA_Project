package com.SA_project.FitBitsSolanki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitBitsSolankiApplicationTests {

	@Test
	void contextLoads() {
	}

}
